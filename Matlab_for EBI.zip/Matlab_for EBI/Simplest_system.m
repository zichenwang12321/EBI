ElikoReconnect();
output = ElikoSample();
PicometerControl('Disconnect');

plot(real(output))